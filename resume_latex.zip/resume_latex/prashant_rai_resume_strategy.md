# RESUME STRATEGY

## 1. POSITIONING
Principal Applied AI leader for complex systems

## 2. DIFFERENTIATION
- Industrial + ML + Product
- Optimization + Reliability
- UQ expertise

## 3. PRIORITIZATION
1. Baker Hughes
2. Caterpillar
3. Safeway
4. Sandia

## 4. SIGNALS
- $M impact
- Leadership
- Systems thinking

## 5. METRICS
Always include revenue, %, scale

## 6. ROLE ADAPTATION
- AI roles → GenAI, agents
- Industrial → IoT, optimization
- Product → roadmap, impact

## 7. LANGUAGE
Use: Led, Built, Delivered
Avoid: Worked on

## 8. TARGET STORY
Owns systems, drives impact, leads teams
