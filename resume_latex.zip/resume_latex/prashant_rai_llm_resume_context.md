# CANDIDATE PROFILE: PRASHANT RAI

## 1. SUMMARY (CAN BE REWRITTEN PER JOB)
Senior / Principal-level Applied AI & Data Science leader with 10+ years of experience in:
- Industrial AI, asset-intensive systems, and physical processes
- Time series modeling, optimization, and uncertainty quantification
- Building and scaling ML products end-to-end (0 → production → revenue)

Strong track record of:
- Owning product + modeling + business impact
- Leading cross-functional teams (7–10+ engineers/scientists)
- Delivering measurable impact ($M+ revenue, production gains, cost reduction)
- Creating IP (patents, publications)

## 2. CORE STRENGTHS
### Technical
- Time Series Modeling, Causal Inference, Optimization
- Uncertainty Quantification, Deep Learning
- Generative AI (RAG, agents)

### Systems / Domain
- Industrial IoT, Asset Health, Reliability
- Process Optimization, OEE improvement

### Leadership / Product
- 0→1 product development
- Technical roadmap ownership
- Cross-functional leadership

## 3. EXPERIENCE (EVIDENCE BLOCKS)
### Baker Hughes
- Built reliability + optimization framework
- Launched 2 patent products (~$4M impact)
- Delivered $20M production gains
- Led 7+ team

### Caterpillar
- Deep learning on 50K+ machines
- Patented anomaly detection

### Safeway
- ML pricing + inventory system (2,300+ stores)

### Sandia
- 100× efficiency algorithms
- 9 publications

## 4. IMPACT METRICS
- $20M+ gains
- $4M+ revenue
- 7–20% improvements
- 50K+ assets

## 5. TOOLS
Python, SQL, AWS, Databricks, Snowflake

## 6. NARRATIVE
"I build AI systems that optimize complex systems under uncertainty."
